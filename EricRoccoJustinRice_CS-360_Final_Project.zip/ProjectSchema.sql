--Drop table section
DROP TABLE Clientinfo CASCADE CONSTRAINTS;
DROP TABLE Contract CASCADE CONSTRAINTS;
DROP TABLE Photographer CASCADE CONSTRAINTS;
DROP TABLE StudioPhotographer CASCADE CONSTRAINTS;
DROP TABLE FreelancePhotographer CASCADE CONSTRAINTS;
DROP TABLE Eventinfo CASCADE CONSTRAINTS;
DROP TABLE Portrait CASCADE CONSTRAINTS;
DROP TABLE OtherEvents CASCADE CONSTRAINTS;
DROP TABLE Proof CASCADE CONSTRAINTS;
DROP TABLE Packag CASCADE CONSTRAINTS;
DROP TABLE PackagePrice CASCADE CONSTRAINTS;

--Create table section
--Stores Client information
CREATE TABLE Clientinfo
(
    ClientID VARCHAR(10) NOT NULL,
    ClientName VARCHAR(30) NOT NULL,
    ServicesDesired VARCHAR(30) NOT NULL,
    ClientLoction VARCHAR(20) NOT NULL,
    ClientTime DATE NOT NULL,
    ClientPhoneNumber VARCHAR(15) NOT NULL,
    PreferredPhotographerName VARCHAR(20),
    CONSTRAINT Clientinfo_PK PRIMARY KEY (ClientID)
);

--stores Phoographer inormation and is parent of StudioPhotographer and FreelancePhotographer
CREATE TABLE Photographer
(
    PhotographerID VARCHAR(10),
    PhotographerName VARCHAR(20) NOT NULL,
    PhotographerType VARCHAR(1),
    ManagerID VARCHAR(10),
    --NEED to make unary relationship
    CONSTRAINT Photographer_PK PRIMARY KEY (PhotographerID)
);

--Stores information about the contract
CREATE TABLE Contract
(
    ContractID VARCHAR(10),
    EventInformation VARCHAR(50) NOT NULL,
    StudioEstimate NUMBER(10, 2) NOT NULL,
    TenativeBooking DATE NOT NULL,
    ClientSignature VARCHAR(20) NOT NULL,
    ClientDeposit NUMBER(10,2) NOT NULL,
    PhotographerID VARCHAR(10)NOT NULL,
    ClientID VARCHAR(10) NOT NULL,
    CONSTRAINT Contract_PK PRIMARY KEY (ContractID),
    CONSTRAINT Contract_FK1 FOREIGN KEY (PhotographerID) REFERENCES Photographer (PhotographerID),
    CONSTRAINT Contract_FK2 FOREIGN KEY (ClientID) REFERENCES Clientinfo (ClientID)
);

--Stores studio Photographer id and salary. Child of Photographer
CREATE TABLE StudioPhotographer
(
    SPhotographerID VARCHAR(10),
    StudioSalary NUMBER(10,2) NOT NULL,
    CONSTRAINT StudioPhotographer_PK PRIMARY KEY (SPhotographerID),
    CONSTRAINT StudioPhotographer_FK FOREIGN KEY (SPhotographerID) REFERENCES Photographer (PhotographerID)
);

--stores Freelance Photographer id and pay rate. Child of Photographer
CREATE TABLE FreelancePhotographer
(
    FPhotographerID VARCHAR(10),
    FreelancePayRate NUMBER(10,2) NOT NULL,
    CONSTRAINT FreelancePhotographer_PK PRIMARY KEY (FPhotographerID),
    CONSTRAINT FreelancePhotographer_FK FOREIGN KEY (FPhotographerID) REFERENCES Photographer (PhotographerID)
);

--Stores information about the event. Parent of Portrait and OtherEvents
CREATE TABLE EventInfo
(
    EventID VARCHAR(10),
    EventType VARCHAR(1) NOT NULL,
    CostEstimate NUMBER(10,2) NOT NULL,
    ContractID VARCHAR(10) NOT NULL,
    CONSTRAINT Eventinfo_PK PRIMARY KEY (EventID),
    CONSTRAINT Eventinfo_FK FOREIGN KEY (ContractID) REFERENCES Contract(ContractID)
);

--Stores portrait id and the photographer id who is workin the event. Child of Eventinfo
CREATE TABLE Portrait
(
    EventID VARCHAR(10),
    AssignedPhotographerID VARCHAR(10) NOT NULL,
    CONSTRAINT Portrait_PK PRIMARY KEY (EventID),
    CONSTRAINT Portrait_FK FOREIGN KEY (EventID) REFERENCES Eventinfo(EventID)
);

--Stores the other event id and the ids of the photographers working. Child of Eventinfo
CREATE TABLE OtherEvents
(
    EventId VARCHAR(10) NOT NULL,
    PrimaryPhotographerID VARCHAR(10) NOT NULL,
    AssistantPhotographerID VARCHAR(10) NOT NULL,
    CONSTRAINT OtherEvents_PK PRIMARY KEY (EventID),
    CONSTRAINT OtherEvents_FK FOREIGN KEY (EventID) REFERENCES Eventinfo(EventID)
);

--Stores the packageCombunation id and the price
CREATE TABLE PackagePrice
(
    PackageCombinations VARCHAR(20) NOT NULL,
    PackagePrice NUMBER(10,2) NOT NULL,
    CONSTRAINT PackagePrice_PK PRIMARY KEY (PackageCombinations)
);

--Stores the package options and the proofs associated
CREATE TABLE Packag
(
    PackageID VARCHAR(10) NOT NULL,
    PackageProofs VARCHAR(10) NOT NULL,
    PackageCombinations VARCHAR(10) NOT NULL,
    CONSTRAINT Packag_PK PRIMARY KEY (PackageID),
    CONSTRAINT Packag_FK FOREIGN KEY (PackageCombinations) REFERENCES PackagePrice (PackageCombinations)
);

--Stores information about the proofs
CREATE TABLE Proof
(
    ProofID VARCHAR(10) NOT NULL,
    ProofComments VARCHAR(50),
    ProofDate DATE NOT NULL,
    AdditionalTimeRequested VARCHAR(1) NOT NULL,
    PackageID VARCHAR(10) NOT NULL,
    ContractID VARCHAR(10) NOT NULL,
    CONSTRAINT Proof_PK PRIMARY KEY (ProofID),
    CONSTRAINT Proof_FK1 FOREIGN KEY (ContractID) REFERENCES Contract (ContractID),
    CONSTRAINT Proof_FK2 FOREIGN KEY (PackageID) REFERENCES Packag(PackageID)
);

--Insert data
INSERT INTO Clientinfo VALUES('JS101','John Samson','Portrait','Center Vally', TO_DATE('2023-12-01', 'yyyy-mm-dd'), '123-456-7890','Ron Ligma');
INSERT INTO Clientinfo VALUES('JR548', 'Justin Rice', 'Portrait','Philadelphia', TO_DATE('2023-12-09', 'yyyy-mm-dd'), '252-525-7953', null);
INSERT INTO Clientinfo VALUES('JC079', 'Jewel Cat','Other','The Streets', TO_DATE('2023-12-09', 'yyyy-mm-dd'), '000-000-0000' ,'Ron Ligma');
INSERT INTO Clientinfo VALUES('YT886', 'Yozu Tailwind','Photoshoot','Eorzea', TO_DATE('2023-12-09', 'yyyy-mm-dd'), '123-456-7890' ,'N/A');
INSERT INTO Photographer VALUES ('RL101', 'Ron Ligma', '1', 'RL10');    
INSERT INTO Photographer VALUES ('GK102', 'Geoff Keighley', '2', NULL);
INSERT INTO Contract VALUES ('JSContract', 'Grad pic', 100, TO_DATE('2023-12-03', 'yyyy-mm-dd'), 'Signature', 100, 'RL101', 'JS101');
INSERT INTO StudioPhotographer VALUES ('RL101', 1000);
INSERT INTO FreelancePhotographer VALUES ('GK102', 50);
INSERT INTO Eventinfo VALUES ('GP101', '1', 100, 'JSContract');
INSERT INTO Eventinfo VALUES ('SM102', '2', 200, 'JSContract');
INSERT INTO Portrait VALUES ('GP101', 'RL101');
INSERT INTO OtherEvents VALUES ('SM102', 'John Sugma', 'Bill Forde');
INSERT INTO PackagePrice VALUES ('jd', 100);
INSERT INTO Packag VALUES ('jd439', 'wallet pic', 'jd');
INSERT INTO Proof VALUES ('jd109', 'Looks good', TO_DATE('2023-12-01', 'yyyy-mm-dd'), 'N', 'jd439','JSContract');