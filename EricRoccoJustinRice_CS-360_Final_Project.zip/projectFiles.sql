--Drop table section
DROP TABLE Clientinfo CASCADE CONSTRAINTS;
DROP TABLE Contract CASCADE CONSTRAINTS;
DROP TABLE Photographer CASCADE CONSTRAINTS;
DROP TABLE StudioPhotographer CASCADE CONSTRAINTS;
DROP TABLE FreelancePhotographer CASCADE CONSTRAINTS;
DROP TABLE Eventinfo CASCADE CONSTRAINTS;
DROP TABLE Portrait CASCADE CONSTRAINTS;
DROP TABLE OtherEvents CASCADE CONSTRAINTS;
DROP TABLE Proof CASCADE CONSTRAINTS;
DROP TABLE Packag CASCADE CONSTRAINTS;
DROP TABLE PackagePrice CASCADE CONSTRAINTS;

--Create table section
--Stores Client information
CREATE TABLE Clientinfo
(
    ClientID VARCHAR(10) NOT NULL,
    ClientName VARCHAR(30) NOT NULL,
    ServicesDesired VARCHAR(30) NOT NULL,
    ClientLoction VARCHAR(20) NOT NULL,
    ClientTime DATE NOT NULL,
    ClientPhoneNumber VARCHAR(15) NOT NULL,
    PreferredPhotographerName VARCHAR(20),
    CONSTRAINT Clientinfo_PK PRIMARY KEY (ClientID)
);

--stores Phoographer inormation and is parent of StudioPhotographer and FreelancePhotographer
CREATE TABLE Photographer
(
    PhotographerID VARCHAR(10),
    PhotographerName VARCHAR(20) NOT NULL,
    PhotographerType VARCHAR(1),
    ManagerID VARCHAR(10),
    --NEED to make unary relationship
    CONSTRAINT Photographer_PK PRIMARY KEY (PhotographerID)
);

--Stores information about the contract
CREATE TABLE Contract
(
    ContractID VARCHAR(10),
    EventInformation VARCHAR(50) NOT NULL,
    StudioEstimate NUMBER(10, 2) NOT NULL,
    TenativeBooking DATE NOT NULL,
    ClientSignature VARCHAR(20) NOT NULL,
    ClientDeposit NUMBER(10,2) NOT NULL,
    PhotographerID VARCHAR(10)NOT NULL,
    ClientID VARCHAR(10) NOT NULL,
    CONSTRAINT Contract_PK PRIMARY KEY (ContractID),
    CONSTRAINT Contract_FK1 FOREIGN KEY (PhotographerID) REFERENCES Photographer (PhotographerID),
    CONSTRAINT Contract_FK2 FOREIGN KEY (ClientID) REFERENCES Clientinfo (ClientID)
);

--Stores studio Photographer id and salary. Child of Photographer
CREATE TABLE StudioPhotographer
(
    SPhotographerID VARCHAR(10),
    StudioSalary NUMBER(10,2) NOT NULL,
    CONSTRAINT StudioPhotographer_PK PRIMARY KEY (SPhotographerID),
    CONSTRAINT StudioPhotographer_FK FOREIGN KEY (SPhotographerID) REFERENCES Photographer (PhotographerID)
);

--stores Freelance Photographer id and pay rate. Child of Photographer
CREATE TABLE FreelancePhotographer
(
    FPhotographerID VARCHAR(10),
    FreelancePayRate NUMBER(10,2) NOT NULL,
    CONSTRAINT FreelancePhotographer_PK PRIMARY KEY (FPhotographerID),
    CONSTRAINT FreelancePhotographer_FK FOREIGN KEY (FPhotographerID) REFERENCES Photographer (PhotographerID)
);

--Stores information about the event. Parent of Portrait and OtherEvents
CREATE TABLE EventInfo
(
    EventID VARCHAR(10),
    EventType VARCHAR(1) NOT NULL,
    CostEstimate NUMBER(10,2) NOT NULL,
    ContractID VARCHAR(10) NOT NULL,
    CONSTRAINT Eventinfo_PK PRIMARY KEY (EventID),
    CONSTRAINT Eventinfo_FK FOREIGN KEY (ContractID) REFERENCES Contract(ContractID)
);

--Stores portrait id and the photographer id who is workin the event. Child of Eventinfo
CREATE TABLE Portrait
(
    EventID VARCHAR(10),
    AssignedPhotographerID VARCHAR(10) NOT NULL,
    CONSTRAINT Portrait_PK PRIMARY KEY (EventID),
    CONSTRAINT Portrait_FK FOREIGN KEY (EventID) REFERENCES Eventinfo(EventID)
);

--Stores the other event id and the ids of the photographers working. Child of Eventinfo
CREATE TABLE OtherEvents
(
    EventId VARCHAR(10) NOT NULL,
    PrimaryPhotographerID VARCHAR(10) NOT NULL,
    AssistantPhotographerID VARCHAR(10) NOT NULL,
    CONSTRAINT OtherEvents_PK PRIMARY KEY (EventID),
    CONSTRAINT OtherEvents_FK FOREIGN KEY (EventID) REFERENCES Eventinfo(EventID)
);

--Stores the packageCombunation id and the price
CREATE TABLE PackagePrice
(
    PackageCombinations VARCHAR(20) NOT NULL,
    PackagePrice NUMBER(10,2) NOT NULL,
    CONSTRAINT PackagePrice_PK PRIMARY KEY (PackageCombinations)
);

--Stores the package options and the proofs associated
CREATE TABLE Packag
(
    PackageID VARCHAR(10) NOT NULL,
    PackageProofs VARCHAR(10) NOT NULL,
    PackageCombinations VARCHAR(10) NOT NULL,
    CONSTRAINT Packag_PK PRIMARY KEY (PackageID),
    CONSTRAINT Packag_FK FOREIGN KEY (PackageCombinations) REFERENCES PackagePrice (PackageCombinations)
);

--Stores information about the proofs
CREATE TABLE Proof
(
    ProofID VARCHAR(10) NOT NULL,
    ProofComments VARCHAR(50),
    ProofDate DATE NOT NULL,
    AdditionalTimeRequested VARCHAR(1) NOT NULL,
    PackageID VARCHAR(10) NOT NULL,
    ContractID VARCHAR(10) NOT NULL,
    CONSTRAINT Proof_PK PRIMARY KEY (ProofID),
    CONSTRAINT Proof_FK1 FOREIGN KEY (ContractID) REFERENCES Contract (ContractID),
    CONSTRAINT Proof_FK2 FOREIGN KEY (PackageID) REFERENCES Packag(PackageID)
);

--Insert data
INSERT INTO Clientinfo VALUES('JS101','John Samson','Portrait','Center Vally', TO_DATE('2023-12-01', 'yyyy-mm-dd'), '123-456-7890','Ron Ligma');
INSERT INTO Clientinfo VALUES('JR548', 'Justin Rice', 'Portrait','Philadelphia', TO_DATE('2023-12-09', 'yyyy-mm-dd'), '252-525-7953', null);
INSERT INTO Clientinfo VALUES('JC079', 'Jewel Cat','Other','The Streets', TO_DATE('2023-12-09', 'yyyy-mm-dd'), '000-000-0000' ,'Ron Ligma');
INSERT INTO Clientinfo VALUES('YT886', 'Yozu Tailwind','Photoshoot','Eorzea', TO_DATE('2023-12-09', 'yyyy-mm-dd'), '123-456-7890' ,'N/A');
INSERT INTO Photographer VALUES ('RL101', 'Ron Ligma', '1', 'RL10');
INSERT INTO Photographer VALUES ('GK102', 'Geoff Keighley', '2', NULL);
INSERT INTO Contract VALUES ('JSContract', 'Grad pic', 100, TO_DATE('2023-12-03', 'yyyy-mm-dd'), 'Signature', 100, 'RL101', 'JS101');
INSERT INTO StudioPhotographer VALUES ('RL101', 1000);
INSERT INTO FreelancePhotographer VALUES ('GK102', 50);
INSERT INTO Eventinfo VALUES ('GP101', '1', 100, 'JSContract');
INSERT INTO Eventinfo VALUES ('SM102', '2', 200, 'JSContract');
INSERT INTO Portrait VALUES ('GP101', 'RL101');
INSERT INTO OtherEvents VALUES ('SM102', 'John Sugma', 'Bill Forde');
INSERT INTO PackagePrice VALUES ('jd', 100);
INSERT INTO Packag VALUES ('jd439', 'wallet pic', 'jd');
INSERT INTO Proof VALUES ('jd109', 'Looks good', TO_DATE('2023-12-01', 'yyyy-mm-dd'), 'N', 'jd439','JSContract');

--Views
--Creates a scheduale of events and who is working
CREATE OR REPLACE VIEW PhotographerSchedule
AS
SELECT PreferredPhotographerName, PhotographerID ,ClientTime
FROM Clientinfo C, Photographer P
WHERE C. PreferredPhotographerName= P.PhotographerName;

--Creates a schedual of all events for the week
CREATE OR REPLACE VIEW Weekly_Schedule
AS
SELECT EventID, EventType, ClientTime
FROM Eventinfo E , Clientinfo C
ORDER BY C.CLientTime;

--Creates a report about a client
CREATE OR REPLACE VIEW ClientReport
AS
SELECT ClientName, EventInformation, ClientLoction, ClientTime, StudioEstimate
FROM ClientInfo C, Contract Con
WHERE C.ClientID = Con.ClientID;

--Procedures
--Creats a package order form
CREATE OR REPLACE PROCEDURE PackageOrderForm
IS
    POFClientID Clientinfo.ClientID%TYPE;
    POFPackageID Packag.PackageID%TYPE;
    POFPackagePrice PackagePrice.PackagePrice%TYPE;
    CURSOR PackageOrderFormCursor IS
        SELECT ClientInfo.ClientID, Packag.PackageID, PackagePrice.PackagePrice
        FROM ClientInfo, Proof, Contract, Packag, PackagePrice
        WHERE Proof.ContractID = Contract.ContractID
        AND Contract.ClientID = ClientInfo.ClientID
        AND Proof.PackageID = Packag.PackageID
        AND PackagePrice.PackageCombinations = Packag.PackageCombinations;
BEGIN
    OPEN PackageOrderFormCursor;
    DBMS_OUTPUT.PUT_LINE('ClientID         PackageID          Package Price');
    LOOP
        FETCH PackageOrderFormCursor INTO POFClientID, POFPackageID, POFPackagePrice;
        EXIT WHEN PackageOrderFormCursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(POFClientID || '         ' || POFPackageID || '          ' || POFPackagePrice);
    END LOOP;
    CLOSE PackageOrderFormCursor;
END;

--Procedure for inquiery form
CREATE OR REPLACE PROCEDURE InquiryForm
IS
    IFClientID ClientInfo.ClientID%TYPE;
    IFClientName ClientInfo.ClientName%TYPE;
    IFServicesDesired ClientInfo.ServicesDesired%TYPE;
    IFClientPhoneNumber ClientInfo.ClientPhoneNumber%TYPE;
    IFClientLoction ClientInfo.ClientLoction%TYPE;
    IFClientTime ClientInfo.ClientTime%TYPE;
    --IFEventInformation Contract.EventInformation%TYPE;
    CURSOR InquiryFormCursor IS
        SELECT ClientID, ClientName, ServicesDesired, ClientPhoneNumber, ClientLoction, ClientTime
        FROM Clientinfo;
BEGIN
    OPEN InquiryFormCursor;
    DBMS_OUTPUT.PUT_LINE('ClientID       Client Name      Services Desired       Location          Date');
    LOOP
        FETCH InquiryFormCursor INTO IFClientID, IFClientName, IFServicesDesired, IFClientPhoneNumber, IFClientLoction, IFClientTime;
        EXIT WHEN InquiryFormCursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(IFClientID ||IFClientName || IFServicesDesired || IFClientPhoneNumber || IFClientLoction || IFClientTime);
    END LOOP;
    CLOSE InquiryFormCursor;
END;

--Triggers
--Used to store notifications
DROP TABLE Updates CASCADE CONSTRAINTS;
CREATE TABLE Updates
(
    Descritpion VARCHAR(255)
);

--Trigger automatically creates a clientID based off the clients first and last name
CREATE OR REPLACE TRIGGER CreateClientID
BEFORE INSERT ON Clientinfo
FOR EACH ROW
DECLARE
    -- Declare variables
    first_initial CHAR(1);
    last_initial CHAR(1);
    new_id INT;
BEGIN
    -- Extract first and last initials
    first_initial := SUBSTR(:NEW.ClientName, 1, 1);
    last_initial := SUBSTR(:NEW.ClientName, -1, 1);

    -- Generate a three-digit number starting at 100
    SELECT COALESCE(MAX(TO_NUMBER(ClientID)), 99) + 1 INTO new_id FROM Clientinfo;

    -- Set the new ClientID
    :NEW.ClientID := TO_CHAR(first_initial || last_initial || LPAD(new_id + 100, 3, '0'));
END;

--Automatically creates a photographerID based off the photographers first and last name
CREATE OR REPLACE TRIGGER CreatePhotographerID
BEFORE INSERT ON Photographer
FOR EACH ROW
DECLARE
    -- Declare variables
    first_initial CHAR(1);
    last_initial CHAR(1);
    new_id INT;
BEGIN
    -- Extract first and last initials
    first_initial := SUBSTR(:NEW.PhotographerName, 1, 1);
    last_initial := SUBSTR(:NEW.PhotographerName, -1, 1);

    -- Generate a three-digit number starting at 100
    SELECT COALESCE(MAX(TO_NUMBER(PhotographerID)), 99) + 1 INTO new_id FROM Photographer;

    -- Set the new ClientID
    :NEW.PhotographerID := TO_CHAR(first_initial || last_initial || LPAD(new_id + 100, 3, '0'));
END;

--Functions
--Calculates the total cost for a client
CREATE OR REPLACE FUNCTION TotalPrice(PackagePrice IN NUMBER, ClientDeposit IN NUMBER, StudioEstimate IN NUMBER)
RETURN NUMBER IS
BEGIN
    RETURN ((PackagePrice) + (ClientDeposit) + (StudioEstimate));
END;

--Calculates the total salary of all studio photographers
CREATE OR REPLACE FUNCTION PayRoll
RETURN DECIMAL
IS
    totalSalary DECIMAL := 0;

BEGIN
    SELECT SUM(StudioSalary) INTO totalSalary
    FROM StudioPhotographer;

    RETURN totalSalary;
END;