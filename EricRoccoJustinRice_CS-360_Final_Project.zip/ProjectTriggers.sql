--Triggers
--Used to store notifications
DROP TABLE Updates CASCADE CONSTRAINTS;
CREATE TABLE Updates
(
    Descritpion VARCHAR(255)
);

--Trigger automatically creates a clientID based off the clients first and last name
CREATE OR REPLACE TRIGGER CreateClientID
BEFORE INSERT ON Clientinfo
FOR EACH ROW
DECLARE
    -- Declare variables
    first_initial CHAR(1);
    last_initial CHAR(1);
    new_id INT;
BEGIN
    -- Extract first and last initials
    first_initial := SUBSTR(:NEW.ClientName, 1, 1);
    last_initial := SUBSTR(:NEW.ClientName, -1, 1);

    -- Generate a three-digit number starting at 100
    SELECT COALESCE(MAX(TO_NUMBER(ClientID)), 99) + 1 INTO new_id FROM Clientinfo;

    -- Set the new ClientID
    :NEW.ClientID := TO_CHAR(first_initial || last_initial || LPAD(new_id + 100, 3, '0'));
END;

--Automatically creates a photographerID based off the photographers first and last name
CREATE OR REPLACE TRIGGER CreatePhotographerID
BEFORE INSERT ON Photographer
FOR EACH ROW
DECLARE
    -- Declare variables
    first_initial CHAR(1);
    last_initial CHAR(1);
    new_id INT;
BEGIN
    -- Extract first and last initials
    first_initial := SUBSTR(:NEW.PhotographerName, 1, 1);
    last_initial := SUBSTR(:NEW.PhotographerName, -1, 1);

    -- Generate a three-digit number starting at 100
    SELECT COALESCE(MAX(TO_NUMBER(PhotographerID)), 99) + 1 INTO new_id FROM Photographer;

    -- Set the new ClientID
    :NEW.PhotographerID := TO_CHAR(first_initial || last_initial || LPAD(new_id + 100, 3, '0'));
END;