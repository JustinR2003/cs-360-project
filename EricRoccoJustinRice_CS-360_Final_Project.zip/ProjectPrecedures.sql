--Procedures
--Creats a package order form
CREATE OR REPLACE PROCEDURE PackageOrderForm
IS
    POFClientID Clientinfo.ClientID%TYPE;
    POFPackageID Packag.PackageID%TYPE;
    POFPackagePrice PackagePrice.PackagePrice%TYPE;
    CURSOR PackageOrderFormCursor IS
        SELECT ClientInfo.ClientID, Packag.PackageID, PackagePrice.PackagePrice
        FROM ClientInfo, Proof, Contract, Packag, PackagePrice
        WHERE Proof.ContractID = Contract.ContractID
        AND Contract.ClientID = ClientInfo.ClientID
        AND Proof.PackageID = Packag.PackageID
        AND PackagePrice.PackageCombinations = Packag.PackageCombinations;
BEGIN
    OPEN PackageOrderFormCursor;
    DBMS_OUTPUT.PUT_LINE('ClientID         PackageID          Package Price');
    LOOP
        FETCH PackageOrderFormCursor INTO POFClientID, POFPackageID, POFPackagePrice;
        EXIT WHEN PackageOrderFormCursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(POFClientID || '         ' || POFPackageID || '          ' || POFPackagePrice);
    END LOOP;
    CLOSE PackageOrderFormCursor;
END;

--Procedure for inquiery form
CREATE OR REPLACE PROCEDURE InquiryForm
IS
    IFClientID ClientInfo.ClientID%TYPE;
    IFClientName ClientInfo.ClientName%TYPE;
    IFServicesDesired ClientInfo.ServicesDesired%TYPE;
    IFClientPhoneNumber ClientInfo.ClientPhoneNumber%TYPE;
    IFClientLoction ClientInfo.ClientLoction%TYPE;
    IFClientTime ClientInfo.ClientTime%TYPE;
    --IFEventInformation Contract.EventInformation%TYPE;
    CURSOR InquiryFormCursor IS
        SELECT ClientID, ClientName, ServicesDesired, ClientPhoneNumber, ClientLoction, ClientTime
        FROM Clientinfo;
BEGIN
    OPEN InquiryFormCursor;
    DBMS_OUTPUT.PUT_LINE('ClientID       Client Name      Services Desired       Location          Date');
    LOOP
        FETCH InquiryFormCursor INTO IFClientID, IFClientName, IFServicesDesired, IFClientPhoneNumber, IFClientLoction, IFClientTime;
        EXIT WHEN InquiryFormCursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(IFClientID ||IFClientName || IFServicesDesired || IFClientPhoneNumber || IFClientLoction || IFClientTime);
    END LOOP;
    CLOSE InquiryFormCursor;
END;