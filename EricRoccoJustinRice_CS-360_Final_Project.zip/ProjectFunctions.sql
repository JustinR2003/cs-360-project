--Functions
--Calculates the total cost for a client
CREATE OR REPLACE FUNCTION TotalPrice(PackagePrice IN NUMBER, ClientDeposit IN NUMBER, StudioEstimate IN NUMBER)
RETURN NUMBER IS
BEGIN
    RETURN ((PackagePrice) + (ClientDeposit) + (StudioEstimate));
END;

--Calculates the total salary of all studio photographers
CREATE OR REPLACE FUNCTION PayRoll
RETURN DECIMAL
IS
    totalSalary DECIMAL := 0;

BEGIN
    SELECT SUM(StudioSalary) INTO totalSalary
    FROM StudioPhotographer;

    RETURN totalSalary;
END;