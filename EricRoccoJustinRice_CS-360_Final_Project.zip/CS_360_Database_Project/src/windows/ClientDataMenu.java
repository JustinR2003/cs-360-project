package windows;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ClientDataMenu{

	
	// Menu for viewing client data 
	private static JTextField searchBar = new JTextField();

	private static JButton searchButton = new JButton("Search");
	private static JButton deleteButton = new JButton("Delete");
	private static JButton backButton = new JButton("Back to Menu");
	// private static JButton editButton = new JButton("Edit");

	private static JRadioButton name = new JRadioButton("Name (Doesn't work)");
	private static JRadioButton clientID = new JRadioButton("Client ID");
	private static JRadioButton off = new JRadioButton();
	private static ButtonGroup buttons = new ButtonGroup();

	private static JTable dataTable = new JTable();

	private static String operation;

	public static JPanel ClientDataPanel(JFrame frame, JPanel panel) throws SQLException, ClassNotFoundException
	{
		searchBar.setText("");
		
		Connection connection = RunDatabase.connect();
		Statement statement = connection.createStatement();
		frame.setTitle("Photographry Studio - Client Data");
		JPanel searchSection = new JPanel();
		searchSection.setMaximumSize(new Dimension(300, 500));		

		panel.setLayout(new BorderLayout());
		off.setVisible(false);
		off.setSelected(true);

		searchBar.setPreferredSize(new Dimension(300, 25));

		name.setActionCommand(operation = name.getText());
		clientID.setActionCommand(operation = clientID.getText());
		
		buttons.add(off);
		buttons.add(clientID);
		
		searchSection.add(clientID);
		searchSection.add(searchBar);
		searchSection.add(searchButton);
		searchSection.add(deleteButton);
		searchSection.add(backButton);

		JPanel menuSection = new JPanel();
		menuSection.setMaximumSize(new Dimension(500, 500));
		menuSection.setBackground(Color.WHITE);

		DefaultTableModel table = new DefaultTableModel(new String[] {"Client ID", "Client Name", "Client Location", "Client Time", "Client Phone Number", "Services Desired", "Preferred Photographer Name"}, 0);
		String sql = "SELECT * FROM Clientinfo";
		ResultSet results = statement.executeQuery(sql);

		while (results.next())
		{
			String cID = results.getString("ClientID");
			String cName = results.getString("ClientName");
			String cLoc = results.getString("ClientLoction");
			String cTime = results.getString("ClientTime");
			String cPN = results.getString("ClientPhoneNumber");
			String cS = results.getString("ServicesDesired");
			String cPPN = results.getString("PreferredPhotographerName");

			table.addRow(new Object[] {cID, cName, cLoc, cTime, cPN, cS, cPPN});
		}
		
		dataTable.setModel(table);
		dataTable.setEnabled(false);
		dataTable.getTableHeader().setReorderingAllowed(false);
		JScrollPane tableWindow;
		tableWindow = new JScrollPane(dataTable);
		tableWindow.setPreferredSize(new Dimension(600, 500));

		
		menuSection.add(tableWindow);

		panel.add(menuSection, BorderLayout.CENTER);
		panel.add(searchSection, BorderLayout.NORTH);

		// Goes back to the previous menu
		backButton.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(backButton))
					try
				{
						panel.setVisible(false);
						frame.getContentPane().removeAll();
						JPanel dataMenu = new JPanel();
						dataMenu = DataMenu.dataMenu(frame, dataMenu);
						frame.setContentPane(dataMenu);
						frame.revalidate();
						frame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		
		// Deletes the user entry for a table based off of the client ID
		deleteButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				if (event.getSource().equals(deleteButton))
					try
				{
						if (off.isSelected())
						{
							JOptionPane.showMessageDialog(panel, "Select data type to delete.");
						}
						else
						{
							if (!(searchBar.getText().equals("")))
							{
								String del;
								if (operation.equals("Client ID"))
								{
									del = "DELETE FROM Clientinfo WHERE ClientID = '" + searchBar.getText() + "'";
									statement.executeQuery(del);
									JOptionPane.showMessageDialog(panel, "Entry deleted.");
									off.setSelected(true);
									searchBar.setText("");
									panel.setVisible(false);
									frame.getContentPane().removeAll();
									JPanel clientData = new JPanel();
									clientData = ClientDataMenu.ClientDataPanel(frame, clientData);
									frame.setContentPane(clientData);
									frame.revalidate();
									frame.repaint();
								}
								else if (operation.equals("Name"))
								{
									del = "DELETE WHERE Clientinfo ClientName LIKE '%" + searchBar.getText() + "%'";
									statement.executeQuery(del);
									JOptionPane.showMessageDialog(panel, "Entry deleted.");
									off.setSelected(true);
									searchBar.setText("");
									table.fireTableDataChanged();
									dataTable.repaint();
								}

							}
						}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		
//		editButton.addActionListener(new ActionListener()
//				{
//			
//				});
		return panel;
	}
}