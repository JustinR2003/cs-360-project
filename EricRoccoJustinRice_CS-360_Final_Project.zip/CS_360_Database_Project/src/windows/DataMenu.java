package windows;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class DataMenu {
	
	// menu for viewing data
	private static JButton clientinfo;
	private static JButton eventinfo;
	private static JButton packageinfo;
	private static JButton priceinfo;
	private static JButton backButton;

	public static JPanel dataMenu(JFrame mainFrame, JPanel panel)
	{
		mainFrame.setTitle("Photography Studio - Data Menu");
		mainFrame.setSize(800, 900);
		mainFrame.setResizable(false);
		
		clientinfo = new JButton("Client Information");
		eventinfo = new JButton("Event Information");
		packageinfo = new JButton("Package Information");
		priceinfo = new JButton("Price Information");
		backButton = new JButton("Back to Menu");
		
		backButton.setSize(30,50);
		clientinfo.setSize(50, 50);
		eventinfo.setSize(50, 50);
		packageinfo.setSize(50, 50);
		priceinfo.setSize(50, 50);
		
		panel.add(clientinfo);
		panel.add(eventinfo);
		panel.add(packageinfo);
		panel.add(priceinfo);
		panel.add(backButton);
		
		
		// Open the client info data menu
		clientinfo.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(clientinfo))
					try
				{
						panel.setVisible(false);
						mainFrame.getContentPane().removeAll();
						JPanel clientData = new JPanel();
						clientData = ClientDataMenu.ClientDataPanel(mainFrame, clientData);
						mainFrame.setContentPane(clientData);
						mainFrame.revalidate();
						mainFrame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		
		// Goes back to the previous menu
		backButton.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(backButton))
					try
				{
						panel.setVisible(false);
						mainFrame.getContentPane().removeAll();
						JPanel mainMenu = new JPanel();
						mainMenu = FrontEndMenus.mainMenu(mainFrame, mainMenu);
						mainFrame.setContentPane(mainMenu);
						mainFrame.revalidate();
						mainFrame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		
		return panel;
	}
	
}