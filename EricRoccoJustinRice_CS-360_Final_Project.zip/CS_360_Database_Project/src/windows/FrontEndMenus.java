package windows;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FrontEndMenus {

	// Main menu page
	private static JButton clientinfo;
	private static JButton eventinfo;
	private static JButton packageinfo;
	private static JButton priceinfo;
	private static JButton data;
	private static JButton staff;
	private static JButton logout;

	public static JPanel mainMenu(JFrame mainFrame, JPanel panel)
	{
		mainFrame.setTitle("Photography Studio");
		mainFrame.setSize(800, 900);
		mainFrame.setResizable(false);
		clientinfo = new JButton("Client Information");
		eventinfo = new JButton("Event Information");
		packageinfo = new JButton("Package Information");
		priceinfo = new JButton("Price Information");
		data = new JButton("Data");
		staff = new JButton("Staff");
		logout = new JButton("Log Out");

		clientinfo.setSize(50, 50);
		eventinfo.setSize(50, 50);
		packageinfo.setSize(50, 50);
		priceinfo.setSize(50, 50);
		data.setSize(30, 50);
		staff.setSize(30, 50);
		logout.setSize(30,50);

		panel.add(clientinfo);
		panel.add(eventinfo);
		panel.add(packageinfo);
		panel.add(priceinfo);
		panel.add(data);
		panel.add(staff);
		panel.add(logout);
		
		// Enters the menu to input client information
		clientinfo.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(clientinfo))
					try
				{
						panel.setVisible(false);
						mainFrame.getContentPane().removeAll();
						JPanel clientInfo = new JPanel();
						clientInfo = ClientInfoMenu.ClientInfoPanel(mainFrame, clientInfo);
						mainFrame.setContentPane(clientInfo);
						mainFrame.revalidate();
						mainFrame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		// Enters the menu to enter event information
		eventinfo.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(eventinfo))
					try
				{
						panel.setVisible(false);
						mainFrame.getContentPane().removeAll();
						JPanel eventInfo = new JPanel();
						eventInfo = EventInformationMenu.EventInformationPanel(mainFrame, eventInfo);
						mainFrame.setContentPane(eventInfo);
						mainFrame.revalidate();
						mainFrame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		// Enters the data selection menu
		data.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				if (event.getSource().equals(data))
					try
				{
						panel.setVisible(false);
						mainFrame.getContentPane().removeAll();
						JPanel dataScreen = new JPanel();
						dataScreen = DataMenu.dataMenu(mainFrame, dataScreen);
						mainFrame.setContentPane(dataScreen);
						mainFrame.revalidate();
						mainFrame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		// Signs out of the program
		logout.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(logout))
					try
				{
						panel.setVisible(false);
						mainFrame.getContentPane().removeAll();
						JPanel logIn = new JPanel();
						logIn = ConnectionScreen.LogInPanel(mainFrame, logIn);
						mainFrame.setContentPane(logIn);
						mainFrame.revalidate();
						mainFrame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});

		return panel;
	}
}