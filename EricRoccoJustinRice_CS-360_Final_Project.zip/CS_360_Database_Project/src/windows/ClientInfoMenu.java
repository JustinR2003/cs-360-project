package windows;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

import javax.swing.*;
//import javax.swing.border.*;

public class ClientInfoMenu 
{
	
	// Menu for adding client information
	private static JButton testButton;
	private static JPanel header;
	private static JButton addInfo;

	private static JLabel fName = new JLabel("First Name", SwingConstants.RIGHT);
	private static JLabel lName = new JLabel("Last Name", SwingConstants.RIGHT);
	private static JLabel services = new JLabel("Services Desired", SwingConstants.RIGHT);
	private static JLabel phoneNumber= new JLabel("Phone Number", SwingConstants.RIGHT);
	private static JLabel address = new JLabel("Address", SwingConstants.RIGHT);
	private static JLabel photographerName = new JLabel("Preferred Photographer Name (Optional)", SwingConstants.RIGHT);

	private static JTextField fNameField;
	private static JTextField lNameField;
	private static JTextField servicesField;
	private static JTextField phoneNumberField;
	private static JTextField addressField;
	private static JTextField photographerNameField;

	private static String nameTxt;
	private static String servicesDesired;
	private static String phoneNum;
	private static String addressTxt;
	private static String prefPhotoName;
	private static Connection con;
	private static Statement state;

	public static JPanel ClientInfoPanel(JFrame frame, JPanel panel) throws ClassNotFoundException, SQLException
	{
		con = RunDatabase.connect();
		state = con.createStatement();
		
		header = new JPanel(new GridLayout(7,2, 10, 5));

		fNameField = new JTextField();
		fNameField.setPreferredSize(new Dimension(100,10));
		lNameField = new JTextField();
		lNameField.setPreferredSize(new Dimension(100,10));

		servicesField = new JTextField();
		servicesField.setSize(150,10);

		phoneNumberField = new JTextField();
		phoneNumberField.setSize(150, 10);

		addressField = new JTextField();
		addressField.setSize(150, 10);

		photographerNameField = new JTextField();
		photographerNameField.setSize(150, 10);

		testButton = new JButton("Back to Menu");
		testButton.setSize(30, 50);

		addInfo = new JButton("Add Information");
		addInfo.setSize(50, 50);

		header.setPreferredSize(new Dimension(500,500));

		header.add(fName);
		header.add(fNameField);
		
		header.add(lName);
		header.add(lNameField);
		

		header.add(services);
		header.add(servicesField);

		header.add(phoneNumber);
		header.add(phoneNumberField);

		header.add(address);
		header.add(addressField);

		header.add(photographerName);
		header.add(photographerNameField);

		header.add(testButton);
		header.add(addInfo);



		panel.setLayout(new FlowLayout());

		panel.add(header);

		frame.setTitle("Photography Studio - Client Information");
		
		// Goes back to the previous menu
		testButton.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(testButton))
					try
				{
						panel.setVisible(false);
						frame.getContentPane().removeAll();
						JPanel mainMenu = new JPanel();
						mainMenu = FrontEndMenus.mainMenu(frame, mainMenu);
						frame.setContentPane(mainMenu);
						frame.revalidate();
						frame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		
		// Adds info from the fields to the database.
		addInfo.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(addInfo))
					try
				{
						if (!(lNameField.getText().equals(""))) 
						{
							nameTxt = fNameField.getText() + " " + lNameField.getText();
							servicesDesired = servicesField.getText();
							addressTxt = addressField.getText();
							phoneNum = phoneNumberField.getText();
							prefPhotoName = photographerNameField.getText();

							if (!(nameTxt.equals("") || servicesDesired.equals("") || addressTxt.equals("") || phoneNum.equals("")))
							{
								Random rand = new Random();
								int ID = rand.nextInt(9998);
								String ClientID;
								char fInit;
								char lInit;
								fInit = fNameField.getText().charAt(0);
								lInit = lNameField.getText().charAt(0);
								ClientID = "" + fInit + lInit + ID;
								
								String sql = "INSERT INTO Clientinfo VALUES ('" + ClientID + "', '" + nameTxt + "', '" + servicesDesired + "', '"+ addressTxt + "', SYSDATE, '" + phoneNum + "', '" + prefPhotoName + "')";
								state.executeQuery(sql);
								
								JOptionPane.showMessageDialog(header, "Client Information added.");
								System.out.println(nameTxt);
								System.out.println(servicesDesired);
								System.out.println(addressTxt);
								System.out.println(phoneNum);
								System.out.println(prefPhotoName);

								fNameField.setText("");
								lNameField.setText("");
								servicesField.setText("");
								addressField.setText("");
								phoneNumberField.setText("");
								photographerNameField.setText("");
							}
							else 
								JOptionPane.showMessageDialog(header, "Please enter valid information.");
						}
						else
							JOptionPane.showMessageDialog(header, "Please enter valid information.");

				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});

		//		addInfo.addActionListener(new ActionListener()
		//		{
		//			public void actionPerformed(ActionEvent event) {
		//				if (event.getSource().equals(addInfo))
		//					try
		//				{
		//						
		//
		//				} catch (Exception e)
		//				{
		//					e.printStackTrace();
		//
		//				}
		//			}
		//		});
		return panel;
	}
}