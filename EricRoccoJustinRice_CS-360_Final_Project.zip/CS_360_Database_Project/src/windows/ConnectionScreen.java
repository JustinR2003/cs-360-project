package windows;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.*;
// import java.awt.event.*;
import javax.swing.*;

public class ConnectionScreen
{

	// Log-in screen
	private static JLabel userName;
	private static JLabel userPass;

	private static JButton login;
	private static JButton exit = new JButton("Exit");

	private static JTextField userNameField;
	private static JPasswordField userPassField;

	private static String user;
	private static String pass;


	public static JPanel LogInPanel(JFrame frame, JPanel panel)
	{
		frame.setTitle("Photography Studio - Log In");
		frame.setSize(800, 900);
		frame.setResizable(false);
		JPanel screenPane = new JPanel(new GridLayout(5, 2, 10, 5));

		userName = new JLabel("User Name", SwingConstants.RIGHT);
		userPass = new JLabel("Password", SwingConstants.RIGHT);

		login = new JButton("Log In");
		login.setSize(30, 50);

		userNameField = new JTextField();
		userNameField.setSize(150,10);

		userPassField = new JPasswordField();
		userPassField.setSize(150,10);

		// Once the log in button is pressed, it will try to connect to the database
		// using the entered credentials.
		login.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				if (event.getSource().equals(login))
					try
				{
						user = userNameField.getText();
						
						String string = new String(userPassField.getPassword());
						pass = string;
						if (!(user.equals("") && pass.equals(""))) 
						{
							if (user.equals("1"))
							{
								try 
								{
									Connection connected = FrontEndDriver.connect(user);
									if (connected != null)
									{
										panel.setVisible(false);
										frame.getContentPane().removeAll();
										JPanel mainMenu = new JPanel();
										mainMenu = FrontEndMenus.mainMenu(frame, mainMenu);
										frame.setContentPane(mainMenu);
										frame.revalidate();
										frame.repaint();
									}
								} catch (Exception e) 
								{
									e.printStackTrace();
								} 
							}
							else
							{
								try 
								{
									Connection connected = FrontEndDriver.connect(user, pass);
									if (connected != null)
									{
										panel.setVisible(false);
										frame.getContentPane().removeAll();
										JPanel mainMenu = new JPanel();
										mainMenu = FrontEndMenus.mainMenu(frame, mainMenu);
										frame.setContentPane(mainMenu);
										frame.revalidate();
										frame.repaint();
									}
								} catch (Exception e) 
								{
									e.printStackTrace();
									JOptionPane.showMessageDialog(screenPane, "Invalid credentials.");
									userNameField.setText("");
									userPassField.setText("");
								}
							} 
						}else
						{
							JOptionPane.showMessageDialog(screenPane, "Please enter credentials.");
						}
				}catch (Exception except) 
				{
					except.printStackTrace();
				}
			}
		});
		// Closes the program
		exit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(exit))
					try
				{
						JOptionPane.showMessageDialog(screenPane, "Exiting program.");
						System.exit(0);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		screenPane.add(userName);
		screenPane.add(userNameField);

		screenPane.add(userPass);
		screenPane.add(userPassField);

		screenPane.add(exit);
		screenPane.add(login);

		panel.add(screenPane);
		return panel;
	}
}