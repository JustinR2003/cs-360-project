package windows;
import java.awt.Dimension;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class FrontEndDriver {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {


		JFrame frame;
		JPanel panel = new JPanel();

		frame = new JFrame("Photography Studio");
		frame.setContentPane(ConnectionScreen.LogInPanel(frame, panel));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setMinimumSize(new Dimension(750, 500));
		frame.setVisible(true);

	}
	
	public static Connection connect(String u, String p) throws SQLException, ClassNotFoundException 
	{
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = u; // Will be personalized
		String password = p; // Will be personalized
		
		System.out.println("Connecting to Database.");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection connection = DriverManager.getConnection(url, user, password);
		System.out.println(connection.toString());
		System.out.println("Connection successful.");
		
		return connection;
	}
	
	// This was used for debugging the log in screen
	public static Connection connect(String t) throws SQLException, ClassNotFoundException 
	{
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "Lucki"; // Will be personalized
		String password = "2154"; // Will be personalized
	
		System.out.println("Connecting to Database.");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection connection = DriverManager.getConnection(url, user, password);
		System.out.println(connection.toString());
		System.out.println("Connection successful.");
		
		return connection;
	}
	
//	private void runSQLQuery1() throws ClassNotFoundException, SQLException
//	{
//		Connection connection = connect();
//		try
//		{
//			Statement str = connection.createStatement();
//			String sql = "CREATE TABLE " + 
//						 "testTable " + 
//						 "(ID VARCHAR2(20) NOT NULL, " +
//						 "name VARCHAR2(10), " +
//						 "PRIMARY KEY (ID))";
//			str.executeUpdate(sql);
//		} catch (Exception e) 
//		{
//			e.printStackTrace();
//		}
//		
//	}
}

