package windows;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

import javax.swing.*;

public class EventInformationMenu
{
	
	// Menu for adding events
	private static Connection connection;
	private static Statement statement;

	private static String eventType = "";
	private static String costEstimateTxt;
	private static String eventLocationTxt;
	private static String clientName;

	private static JButton addInfo;
	private static JButton backButton;

	private static JPanel checkboxes;
	private static JPanel input;
	private static JPanel executePanel;

	private static ButtonGroup buttons = new ButtonGroup();

	private static JTextField costEstimate = new JTextField();
	private static JTextField eventLocation = new JTextField();

	private static JRadioButton portraitButton = new JRadioButton("Portrait");
	private static JRadioButton otherButton = new JRadioButton("Other");
	private static JRadioButton off = new JRadioButton();

	private static JComboBox<String> clients;

	private static String[] clientNames = new String[999];	

	private static JLabel costEstimateLabel = new JLabel("Cost Estimate", SwingConstants.RIGHT);
	private static JLabel eventLocationLabel = new JLabel("Event Location", SwingConstants.RIGHT);
	private static JLabel clientLabel = new JLabel("Client", SwingConstants.RIGHT);

	private static ResultSet names;

	public static JPanel EventInformationPanel(JFrame frame, JPanel panel) throws ClassNotFoundException, SQLException
	{
		connection = RunDatabase.connect();
		statement = connection.createStatement();
		names = statement.executeQuery("SELECT ClientName FROM Clientinfo");

		frame.setTitle("Photography Studio - Event Information");
		panel.setLayout(new GridLayout(4,1,5,10));

		checkboxes = new JPanel(new FlowLayout());
		checkboxes.setSize(150,10);
		buttons.add(portraitButton);
		buttons.add(otherButton);
		buttons.add(off);
		off.setVisible(false);
		off.setSelected(true);

		int i = 0;
		while (names.next())
		{
			String cName = names.getString("ClientName");
			clientNames[i] = cName;
			i++;
		}

		clients = new JComboBox<String>(clientNames);

		clients.addActionListener(new ActionListener()
		{
			public void actionPerformed (ActionEvent event)
			{
				if (event.getSource().equals(clients))
				try
				{
					clientName = clients.getSelectedItem().toString();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});

		portraitButton.setActionCommand(eventType = portraitButton.getText());
		checkboxes.add(portraitButton);
		otherButton.setActionCommand(eventType = otherButton.getText());
		checkboxes.add(otherButton);

		input = new JPanel(new GridLayout(3, 2, 10, 5));
		input.setSize(new Dimension(150, 10));

		costEstimate.setSize(1, 10);
		eventLocation.setSize(150, 10);

		input.add(costEstimateLabel);
		input.add(costEstimate);

		input.add(eventLocationLabel);
		input.add(eventLocation);

		input.add(clientLabel);
		input.add(clients);


		executePanel = new JPanel(new FlowLayout());
		addInfo = new JButton("Add Information");
		addInfo.setSize(50, 50);
		backButton = new JButton("Back to Menu");
		backButton.setSize(30,50);
		executePanel.add(backButton);
		executePanel.add(addInfo);

		panel.add(checkboxes);
		panel.add(input);
		panel.add(executePanel);

		backButton.addActionListener(new ActionListener()
		{

			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(backButton))
					try
				{
						panel.setVisible(false);
						frame.getContentPane().removeAll();
						JPanel mainMenu = new JPanel();
						mainMenu = FrontEndMenus.mainMenu(frame, mainMenu);
						frame.setContentPane(mainMenu);
						frame.revalidate();
						frame.repaint();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
		// Adds info from the fields to the database.
		// Sadly this doesn't work, so it just shows a pop-up window of what the data is.
		addInfo.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) 
			{
				if (event.getSource().equals(addInfo))
					try
				{
						costEstimateTxt = costEstimate.getText();
						eventLocationTxt = eventLocation.getText();

						if (off.isSelected())
							JOptionPane.showMessageDialog(panel, "Please enter valid information.");
						else if (!(clientName.equals("") || eventType.equals("") || costEstimateTxt.equals("") && eventLocationTxt.equals("")))
						{
							System.out.println(clientName);
							System.out.println(eventType);
							System.out.println(costEstimateTxt);
							System.out.println(eventLocationTxt);

							String EventID;
							// int randContract;
							Random rand = new Random();
							int ID;
							ID = rand.nextInt(9998);
							char randChar1;
							char randChar2;
							if (eventType.equals("Portrait"))
								eventType = "P";
							else
								eventType = "O";
							// randContract = rand.nextInt(9998);
							// String ContractID = "" + clientName.charAt(0) + randContract;
							randChar1 = (char) rand.nextInt(64, 91);
							randChar2 = (char) rand.nextInt(64, 91);

							EventID = "" + randChar1 + randChar2 + ID;

//							String sql = "INSERT INTO EventInfo VALUES ('" + EventID + "', '" + eventType + "', '" + costEstimateTxt + "', '" + ContractID +"')";
//							statement.executeQuery(sql);

							System.out.println(clientName);
							System.out.println(eventType);
							System.out.println(costEstimateTxt);
							System.out.println(eventLocationTxt);
							//JOptionPane.showMessageDialog(panel, "Event Information added.");
							JOptionPane.showMessageDialog(panel, "Client Name: " + clientName +
																 "\n Event Type: " + eventType +
																 "\n Cost Estimate: " + costEstimateTxt + 
																 "\n Event Location: " + eventLocationTxt +
																 "\n Event ID: " + EventID);
							costEstimate.setText("");
							eventLocation.setText("");
							off.setSelected(true);
							portraitButton.setSelected(false);
							otherButton.setSelected(false);
						}
						else
							JOptionPane.showMessageDialog(panel, "Please enter valid information.");

				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});

		return panel;
	}

}