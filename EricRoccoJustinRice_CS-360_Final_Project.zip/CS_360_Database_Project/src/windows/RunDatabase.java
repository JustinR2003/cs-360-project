package windows;
import java.sql.*;

public class RunDatabase{
	
static Connection connect() throws SQLException, ClassNotFoundException 
	{
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "Lucki"; // Will be personalized
		String password = "2154"; // Will be personalized
		
		System.out.println("Connecting to Database.");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection connection = DriverManager.getConnection(url, user, password);
		System.out.println(connection.toString());
		System.out.println("Connection successful.");
		
		return connection;
	}
	
//	private void runSQLQuery1() throws ClassNotFoundException, SQLException
//	{
//		Connection connection = connect();
//		try
//		{
//			Statement str = connection.createStatement();
//			String sql = "CREATE TABLE " + 
//						 "testTable " + 
//						 "(ID VARCHAR2(20) NOT NULL, " +
//						 "name VARCHAR2(10), " +
//						 "PRIMARY KEY (ID))";
//			str.executeUpdate(sql);
//		} catch (Exception e) 
//		{
//			e.printStackTrace();
//		}
//
//	}
}
