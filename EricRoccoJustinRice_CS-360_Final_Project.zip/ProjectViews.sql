--Views
--Creates a scheduale of events and who is working
CREATE OR REPLACE VIEW PhotographerSchedule
AS
SELECT PreferredPhotographerName, PhotographerID ,ClientTime
FROM Clientinfo C, Photographer P
WHERE C. PreferredPhotographerName= P.PhotographerName;

--Creates a schedual of all events for the week
CREATE OR REPLACE VIEW Weekly_Schedule
AS
SELECT EventID, EventType, ClientTime
FROM Eventinfo E , Clientinfo C
ORDER BY C.CLientTime;

--Creates a report about a client
CREATE OR REPLACE VIEW ClientReport
AS
SELECT ClientName, EventInformation, ClientLoction, ClientTime, StudioEstimate
FROM ClientInfo C, Contract Con
WHERE C.ClientID = Con.ClientID;